declare interface IStollePpWebPartStrings {
  PropertyPaneDescription: string;
  BasicGroupName: string;
  DescriptionFieldLabel: string;
  PropertyPanePartNo: string;
  CustomerNoFieldLabel: string;  
}

declare module 'StollePpWebPartStrings' {
  const strings: IStollePpWebPartStrings;
  export = strings;
}
