/* tslint:disable */
require('./StolleCo.module.css');
const styles = {
  StolleCo: 'StolleCo_1bedb731',
  container: 'container_1bedb731',
  row: 'row_1bedb731',
  column: 'column_1bedb731',
  'ms-Grid': 'ms-Grid_1bedb731',
  title: 'title_1bedb731',
  subTitle: 'subTitle_1bedb731',
  subTitleLarge: 'subTitleLarge_1bedb731',
  subTitleXL: 'subTitleXL_1bedb731',
  outputText: 'outputText_1bedb731',
  description: 'description_1bedb731',
  label: 'label_1bedb731',
  input: 'input_1bedb731',
  inputlarge: 'inputlarge_1bedb731',
  inputmedium: 'inputmedium_1bedb731',
  button: 'button_1bedb731',
};

export default styles;
/* tslint:enable */