import * as React from 'react';
import styles from './StollePpWebPart.module.scss';
import { IStollePpProps } from './IStollePpProps';

export default class StollePp extends React.Component<IStollePpProps, {}> {

  constructor(props) {
    super(props);
  }

  public state = {
    saveInProcess: false,
    DisplayText: '',
    partno: this.props.partno,
    salesprice: this.props.salesprice,
    currencycode: this.props.currencycode,
    customerno: this.props.customerno 
  };

  private searchStollePP = (e) => {
    e.preventDefault();
    console.log( e);
  }

  public render(): React.ReactElement<IStollePpProps> {
    //const { semanticColors }: IReadonlyTheme = this.props.themeVariant;
    return (
      <div className={styles.stollePp}>
        <div className={styles.container}>
          <div className={styles.row}
            style={{
              backgroundColor: this.props.siteTheme.palette.themeDark,
              color: this.props.siteTheme.palette.white
            }}>

            <br />
            <label className={styles.subTitle}>Part Number : </label>
            <input type='textbox' name='txtPartNoPP' id='txtPartNoPP' className={styles.input}
              value="" placeholder="Enter the Part Number"
              style={{
                backgroundColor: this.props.siteTheme.palette.white,
                color: this.props.siteTheme.palette.black
              }} />
            <br />
            <br />
            <p><button type="button" id="btnSearch" className={styles.button} onClick={this.searchStollePP.bind(this)}
              style={{
                backgroundColor: this.props.siteTheme.palette.themePrimary,
                color: this.props.siteTheme.palette.white
              }}>SEARCH</button>&nbsp;&nbsp;
              <button type="button" id="btnClear" className={styles.button}
                style={{
                  backgroundColor: this.props.siteTheme.palette.themePrimary,
                  color: this.props.siteTheme.palette.white
                }}>CLEAR</button></p>
          </div>
          <div className={styles.row} id="spSearchResultPP"
            style={{
              backgroundColor: this.props.siteTheme.palette.themeDark,
              color: this.props.siteTheme.palette.white
            }}>

          </div>
        </div>
      </div>
    );
  }
}
