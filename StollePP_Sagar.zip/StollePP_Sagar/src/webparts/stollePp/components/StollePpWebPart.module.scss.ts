/* tslint:disable */
require('./StollePpWebPart.module.css');
const styles = {
  stollePp: 'stollePp_4ef47986',
  container: 'container_4ef47986',
  row: 'row_4ef47986',
  column: 'column_4ef47986',
  'ms-Grid': 'ms-Grid_4ef47986',
  title: 'title_4ef47986',
  subTitle: 'subTitle_4ef47986',
  dataText: 'dataText_4ef47986',
  description: 'description_4ef47986',
  label: 'label_4ef47986',
  input: 'input_4ef47986',
  button: 'button_4ef47986',
};

export default styles;
/* tslint:enable */