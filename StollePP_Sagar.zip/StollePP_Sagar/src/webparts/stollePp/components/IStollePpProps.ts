import {
  SPHttpClient,
  SPHttpClientResponse,
  HttpClient,
  HttpClientResponse,
  IHttpClientOptions
} from '@microsoft/sp-http';

import {PageContext} from '@microsoft/sp-page-context';
import { ITheme } from 'office-ui-fabric-react/lib/Styling';


export interface IStollePpProps {
  siteTheme: ITheme;
  description: string;
  httpClient: HttpClient;
  contract: string;
  partno: string;
  currencycode: string;
  salesprice: string;
  customerno: string;
  pagecontext: PageContext;  
}
