/* tslint:disable */
require('./StollePpWebPart.module.css');
const styles = {
  stollePp: 'stollePp_84c5e499',
  container: 'container_84c5e499',
  row: 'row_84c5e499',
  column: 'column_84c5e499',
  'ms-Grid': 'ms-Grid_84c5e499',
  title: 'title_84c5e499',
  subTitle: 'subTitle_84c5e499',
  dataText: 'dataText_84c5e499',
  description: 'description_84c5e499',
  label: 'label_84c5e499',
  input: 'input_84c5e499',
  button: 'button_84c5e499',
};

export default styles;
/* tslint:enable */