import { BaseClientSideWebPart } from '@microsoft/sp-webpart-base';
import { IStollePpProps } from './components/IStollePpProps';
export default class StollePpWebPart extends BaseClientSideWebPart<IStollePpProps> {
    render(): void;
}
