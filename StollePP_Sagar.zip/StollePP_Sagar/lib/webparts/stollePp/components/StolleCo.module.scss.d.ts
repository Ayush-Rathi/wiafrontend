declare const styles: {
    StolleCo: string;
    container: string;
    row: string;
    column: string;
    'ms-Grid': string;
    title: string;
    subTitle: string;
    subTitleLarge: string;
    subTitleXL: string;
    outputText: string;
    description: string;
    label: string;
    input: string;
    inputlarge: string;
    inputmedium: string;
    button: string;
};
export default styles;
