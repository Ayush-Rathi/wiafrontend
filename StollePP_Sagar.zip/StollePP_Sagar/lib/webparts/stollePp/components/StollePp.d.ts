/// <reference types="react" />
import * as React from 'react';
import { IStollePpProps } from './IStollePpProps';
export default class StollePp extends React.Component<IStollePpProps, {}> {
    constructor(props: any);
    state: {
        saveInProcess: boolean;
        DisplayText: string;
        partno: string;
        salesprice: string;
        currencycode: string;
        customerno: string;
    };
    private searchStollePP;
    render(): React.ReactElement<IStollePpProps>;
}
