/// <reference types="react" />
import * as React from 'react';
import { IStollePpProps } from './IStollePpProps';
export default class StollePp extends React.Component<IStollePpProps, {}> {
    render(): React.ReactElement<IStollePpProps>;
}
