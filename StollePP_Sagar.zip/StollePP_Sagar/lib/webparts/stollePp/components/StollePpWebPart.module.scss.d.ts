declare const styles: {
    stollePp: string;
    container: string;
    row: string;
    column: string;
    'ms-Grid': string;
    title: string;
    subTitle: string;
    dataText: string;
    description: string;
    label: string;
    input: string;
    button: string;
};
export default styles;
