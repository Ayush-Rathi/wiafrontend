/* tslint:disable */
require('./StolleCo.module.css');
const styles = {
  StolleCo: 'StolleCo_504a1a8c',
  container: 'container_504a1a8c',
  row: 'row_504a1a8c',
  column: 'column_504a1a8c',
  'ms-Grid': 'ms-Grid_504a1a8c',
  title: 'title_504a1a8c',
  subTitle: 'subTitle_504a1a8c',
  subTitleLarge: 'subTitleLarge_504a1a8c',
  subTitleXL: 'subTitleXL_504a1a8c',
  outputText: 'outputText_504a1a8c',
  description: 'description_504a1a8c',
  label: 'label_504a1a8c',
  input: 'input_504a1a8c',
  inputlarge: 'inputlarge_504a1a8c',
  inputmedium: 'inputmedium_504a1a8c',
  button: 'button_504a1a8c',
};

export default styles;
/* tslint:enable */