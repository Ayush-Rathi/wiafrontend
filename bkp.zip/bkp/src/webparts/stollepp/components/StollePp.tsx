import * as React from 'react';
import styles from './StollePpWebPart.module.scss';
import { IStollePpProps } from './IStollePpProps';
import ShowOutput from './ShowOutPut';
import { Label } from 'office-ui-fabric-react/lib/Label';
import { TextField } from 'office-ui-fabric-react/lib/TextField';
import { DefaultButton, PrimaryButton} from 'office-ui-fabric-react';
import { DetailsList, DetailsListLayoutMode, Selection, IColumn } 
from 'office-ui-fabric-react/lib/DetailsList';//TODO
import queryString from 'query-string';
// import { useLocation } from 'react-router';

import {
  SPHttpClient,
  SPHttpClientResponse,
  HttpClient,
  HttpClientResponse
} from '@microsoft/sp-http';

export interface ISPList {
  result: string;
  message: string;
  data: RecList[];
}
export interface RecList {
  Site: string;
  partNumber: string;
  SalesPrice: string;
  CurrCode: string;
}

export default class StollePp extends React.Component<IStollePpProps, {}> {

  constructor(props) {
    super(props);
    console.log("props");
    this.hideComponent = this.hideComponent.bind(this);
  }

  private hideComponent(name) {
    this.setState({ showHide: !this.state.showHide });
    this.setState({ partNumber: '' });
    this.setState({ searchResults: '' });
    this.showOutput.setDisplayText('');
  }
  public state = {
    showHide: false,
    saveInProcess: false,
    DisplayText: '',
    partNumber: '',
    customerno: '',
    searchResults: [
      { partNumber: "", salesPrice: "", currencyCode: "" }],
    responseData: [
      {
        partNumber: "", SalesPrice: '', CurrCode: ''
      }]
  };

  private showOutput: ShowOutput;


  private searchStollePP(event): void {
    console.log("searchStollePP");
    /* let url = this.props.pagecontext.site;
    console.log(url);
    let params = queryString.parse(url.absoluteUrl);
    console.log(params); */
    
    if (undefined === this.state.partNumber || this.state.partNumber === '') {
      console.log(this.state.partNumber);
      this.showOutput.setDisplayText("Please enter valid Part Number");
      return;
    }
    if (undefined != this.state.partNumber && this.state.partNumber.indexOf(';') > -1) {
      this.showOutput.setDisplayText("Only one Part can be queried at a time.");
      return;
    }
    if (this.state.partNumber.length > 50) {
      //alert("Please enter a valid Part No");    
      this.showOutput.setDisplayText("The Part Number query string is too long");
      return;
    }

    let results =
      [
        { partNumber:this.state.partNumber, salesPrice: "1", currencyCode: "1" }
      ]
    this.setState({ searchResults: results });
    this.setState({ showHide: true });
    this.showOutput.setDisplayText("");

    /*  this._getListData().then((response) => {

       if (response.result == "SUCCESS") {
         this.setState({responseData: response.result});
       }
       else {
         //alert("No Data Found");
         //listContainer.innerHTML = `<p class="${ styles.title }" aligh="left">No Data Found</p>`;
       }
     }); */
  }

  private _getListData(): Promise<ISPList> {
    //let contract: string = document.getElementById("txtContract")["value"];
    let partNumber = this.state.partNumber;
    let customerNo: string = "Ayush";
    //if (contract === '') {contract = 'null'}
    if (customerNo === '') { customerNo = 'null'; }
    if (partNumber === '') { partNumber = 'null'; }
    partNumber = partNumber.replace(/\s+/g, '');
    return this.context.httpClient.get('https://cors-anywhere.herokuapp.com/http://216.241.188.70:63001/ifs/part/pricing/' + partNumber + '/' + customerNo + '/null/null', HttpClient.configurations.v1)
      .then((response: HttpClientResponse): Promise<ISPList> => {
        return response.json();
      });
  }



  private handleChange(event) {
    console.log("In handleChange");
    console.log(event);
    this.setState({ partNumber: event });
  }/* = (
    event: React.FormEvent<HTMLInputElement | HTMLTextAreaElement>,
    newValue: string | undefined,
  ): void => {
    this.setState({
      partNumber: newValue || ''
    });
  }; */

  renderTableHeader() {
    console.log("Inside renderTableHeader");
    console.log(this.state.searchResults[0]);
    if (this.state.searchResults!=undefined  
      && this.state.searchResults[0]!=undefined
      && this.state.searchResults[0].partNumber != "") {
      let header = Object.keys(this.state.searchResults[0])
      return header.map((key, index) => {
        return <th key={index}>{key.toLocaleUpperCase()}</th>
      })
    }
  }


  renderTableData() {
    if (this.state.searchResults!=undefined  
      && this.state.searchResults[0]!=undefined
      && this.state.searchResults[0].partNumber != "") {
      return this.state.searchResults.map((student, index) => {
        const { partNumber, salesPrice, currencyCode } = student //destructuring
        return (
          <tr key={partNumber}>
            <td>{partNumber}</td>
            <td>{salesPrice}</td>
            <td>{currencyCode}</td>
          </tr>
        )
      })
    }
  }

  public render(): React.ReactElement<IStollePpProps> {
    console.log("In render()");
    // console.log(this.state.responseData);
    // let url = window.location.search;/* this.props.location.search; */
    // const urlParams = new URLSearchParams(this.props.pagecontext.site)
    let url = this.props.pagecontext.web;
    console.log(url);
    let params = queryString.parse(url.absoluteUrl);
    console.log(params);

    const showHide = this.state.showHide;
    return (
      <div className={styles.stollePp}>
        <div className={styles.container}>
          <div className={styles.row}
            style={{
              backgroundColor: this.props.siteTheme.palette.themeDark,
              color: this.props.siteTheme.palette.white
            }}>

            <br />
            <Label className={styles.title}>Part Number : </Label>
            <TextField type='textbox' name='txtpartNumberPP' id='txtpartNumberPP' className={styles.input}
              value={this.state.partNumber} onChanged={this.handleChange.bind(this)} placeholder="Enter the Part Number"
              style={{
                backgroundColor: this.props.siteTheme.palette.white,
                color: this.props.siteTheme.palette.black
              }} />
            <br />
            <br />
            <p><DefaultButton text="SEARCH" checked={true} type="button" id="btnSearch" 
            className={styles.button} onClick={this.searchStollePP.bind(this)}
              style={{
                backgroundColor: this.props.siteTheme.palette.themePrimary,
                color: this.props.siteTheme.palette.white
              }}/>&nbsp;&nbsp;
              <PrimaryButton text="CLEAR"  type="button" id="btnClear" 
              className={styles.button} onClick={() => this.hideComponent("showHide")}
                style={{
                  backgroundColor: this.props.siteTheme.palette.themePrimary,
                  color: this.props.siteTheme.palette.white
                }}/></p>
          </div>

          <div className={styles.row}
            style={{
              backgroundColor: this.props.siteTheme.palette.themeDark,
              color: this.props.siteTheme.palette.white
            }}>
            <Label className={styles.subTitle}>Search Results: </Label>
            {showHide &&
              <table id='partPrice' className={styles.custom_class}>
                <tbody>
                  <tr>{this.renderTableHeader()}</tr>
                  {this.renderTableData()}
                </tbody>
              </table>
            }
            <ShowOutput DisplayText={this.state.DisplayText} onRef={ref => (this.showOutput = ref)} />
          </div>

          <div className={styles.row} id="spSearchResultPP"
            style={{
              backgroundColor: this.props.siteTheme.palette.themeDark,
              color: this.props.siteTheme.palette.white
            }}>
          </div>
        </div>
      </div>
    );
  }
}
