/* tslint:disable */
require('./StollePpWebPart.module.css');
const styles = {
  stollePp: 'stollePp_1744667b',
  container: 'container_1744667b',
  row: 'row_1744667b',
  column: 'column_1744667b',
  'ms-Grid': 'ms-Grid_1744667b',
  title: 'title_1744667b',
  subTitle: 'subTitle_1744667b',
  dataText: 'dataText_1744667b',
  description: 'description_1744667b',
  label: 'label_1744667b',
  input: 'input_1744667b',
  button: 'button_1744667b',
  outputText: 'outputText_1744667b',
  custom_class: 'custom_class_1744667b',
};

export default styles;
/* tslint:enable */