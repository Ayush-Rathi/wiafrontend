import * as React from 'react';
import styles from './StollePpWebPart.module.scss';

export interface ShowOutputProps {
    DisplayText: string;
    onRef: Function;
  }

class ShowOutput extends React.Component<ShowOutputProps> {
    public state = {
        DisplayText: this.props.DisplayText        
    };   

    public componentDidMount() {
        this.props.onRef(this);
      }
     public componentWillUnmount() {
        this.props.onRef(undefined);
      }

    public setDisplayText(textVal:string) {
        this.setState({DisplayText:textVal});
    }

    public render() {
        return (
        <div className={styles.outputText}>
            {this.state.DisplayText}            
        </div>
        );
    }
}

export default ShowOutput;