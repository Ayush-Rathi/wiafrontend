import { Version } from '@microsoft/sp-core-library';
import {
  BaseClientSideWebPart,
  IPropertyPaneConfiguration,
  PropertyPaneTextField,
  PropertyPaneLabel
} from '@microsoft/sp-webpart-base';
import { escape } from '@microsoft/sp-lodash-subset';
import * as React from 'react';
import * as ReactDom from 'react-dom';
import StollePp from './components/StollePp';
import { IStollePpProps } from './components/IStollePpProps';

import { createTheme, ITheme } from 'office-ui-fabric-react/lib/Styling';
const ThemeColorsFromWindow: any = (window as any).__themeState__.theme;
const siteTheme: ITheme = createTheme({ //pass this object to your components
  palette: ThemeColorsFromWindow
});

export default class StollePpWebPart extends BaseClientSideWebPart<IStollePpProps> {

  public render(): void {
    const element: React.ReactElement<IStollePpProps > = React.createElement(
      StollePp,
      {
        siteTheme: siteTheme,
        description: this.properties.description,
        httpClient: this.context.httpClient,
        contract: this.properties.contract,
        salesprice: this.properties.salesprice,
        currencycode: this.properties.currencycode,
        partNumber:this.properties.partNumber,
        customerno:this.properties.customerno,
        pagecontext: this.context.pageContext    
      }
    );

    ReactDom.render(element, this.domElement);
  }
}