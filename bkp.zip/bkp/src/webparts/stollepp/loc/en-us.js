define([], function() {
  return {
    "PropertyPaneDescription": "",
    "BasicGroupName": "",
    "DescriptionFieldLabel": "Description:",
    "PartNoFieldLabel": "Part No:",
    "SiteFieldLabel": "Site:",
    "CustomerNoFieldLabel": "Customer No"    
  }
});