/* tslint:disable */
require('./StollePpWebPart.module.css');
const styles = {
  stollePp: 'stollePp_74f63697',
  container: 'container_74f63697',
  row: 'row_74f63697',
  column: 'column_74f63697',
  'ms-Grid': 'ms-Grid_74f63697',
  title: 'title_74f63697',
  subTitle: 'subTitle_74f63697',
  dataText: 'dataText_74f63697',
  description: 'description_74f63697',
  label: 'label_74f63697',
  input: 'input_74f63697',
  button: 'button_74f63697',
};

export default styles;
/* tslint:enable */